import './loading-page.css'

export default function LoadingPage(){
return(
    <div className='loading-page'>
        <div>Loading</div>
    </div>
)
}