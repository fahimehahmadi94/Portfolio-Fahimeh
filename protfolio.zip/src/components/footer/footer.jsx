import "./footer.css"

export default function Footer() {
    return (
        <footer>
            © 2024 All rights reserved by Fahimeh❤️
        </footer>
    )
}